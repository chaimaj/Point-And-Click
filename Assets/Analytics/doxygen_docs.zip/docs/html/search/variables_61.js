var searchData=
[
  ['analyticsdisabled',['analyticsDisabled',['../class_google_universal_analytics.html#a18433803946bc31d7f52676f84d3f1d6',1,'GoogleUniversalAnalytics']]],
  ['appname',['appName',['../class_google_universal_analytics.html#a566df71ed7c5a51cf7947b64c3bbaa62',1,'GoogleUniversalAnalytics']]],
  ['appversion',['appVersion',['../class_google_universal_analytics.html#a5d4a97ee9d51ab588f1d98a076cdf999',1,'GoogleUniversalAnalytics']]]
];
