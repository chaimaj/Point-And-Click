var searchData=
[
  ['initialize',['initialize',['../class_google_universal_analytics.html#a2256b66e01ea94a3710a2e35e3b0b8eb',1,'GoogleUniversalAnalytics']]],
  ['instance',['Instance',['../class_google_universal_analytics.html#ae4d2ea36ead3883e306d11060b9d391a',1,'GoogleUniversalAnalytics']]]
];
